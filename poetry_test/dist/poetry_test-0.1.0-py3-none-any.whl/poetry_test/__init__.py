__version__ = "0.1.1"

def greet(name):
    return f"Hello , {name}"